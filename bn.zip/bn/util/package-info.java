/**
 * Utility classes.
 */
package bn.util;