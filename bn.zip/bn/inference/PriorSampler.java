package bn.inference;

import bn.core.Assignment;
import bn.base.BooleanDomain;
import bn.base.BooleanValue;
import bn.base.CPT;
import bn.base.NamedVariable;
import bn.base.BayesianNetwork;
import bn.core.Distribution;
import bn.core.RandomVariable;

import java.util.List;
import java.util.Random;
import java.util.Set;

import bn.core.Value;
import bn.util.ArraySet;

public class PriorSampler {
	protected BayesianNetwork network;
	protected List<RandomVariable> variables;
	protected Random random = new Random();
	
	//Constructor
	public PriorSampler(BayesianNetwork network) {
		this.network = network;
		this.variables = network.getVariablesSortedTopologically();
	}
	
	//A method which returns an assignment for the variable in the network.
	public Assignment getSample() {
		Assignment assignment = new bn.base.Assignment();
		for (RandomVariable x : variables) {
			assignment.put(x, randomSampleForVariable(x,assignment));
		}
		return assignment;
	}
	
	//a protected method which return a specific value for a specific variable according to a specific assignment 
	//and the conditional probability table for the network.
	protected Value randomSampleForVariable(RandomVariable Xi, Assignment x) {
		bn.core.CPT cpt = network.getCptForVariable(Xi);
		bn.core.Domain domain = Xi.getDomain();
		Double n = random.nextDouble();
		Double doubles = 0.0;
		Distribution dist = new bn.base.Distribution(Xi);
		for(Value i : domain) {
			dist.set(i,cpt.get(i, x));
		}
		dist.normalize();
		for(Value i : domain) {
			doubles += dist.get(i);
			if(n <= doubles) {
				return i;
			}
		}
		return null;
	}
}
