package bn.inference;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Set;
import java.util.Random;

import bn.base.CPT;
import bn.core.Assignment;
import bn.core.BayesianNetwork;
import bn.core.Distribution;
import bn.core.Inferencer;
import bn.core.RandomVariable;
import bn.core.Value;
import bn.base.BooleanDomain;
import bn.base.BooleanValue;
import bn.base.NamedVariable;
import bn.util.ArraySet;
import bn.inference.*;

public class Likelihood_Weighting {

    public Likelihood_Weighting() {
        super();
    }

    public static bn.core.Value Random_sample(RandomVariable X, Assignment ass, BayesianNetwork n) {
        Assignment ass_new = ass.copy();
        HashMap<Value, Double[]> prob_table = new HashMap<Value, Double[]>();
        double sum = 0;
        Double interval[] = new Double[2];
        for (Value value : X.getDomain()) {
            interval = new Double[2];
            ass_new.put(X, value);
            interval[0] = sum;
            sum += n.getProbability(X, ass_new);
            interval[1] = sum;
            prob_table.put(value, interval);
        }

        Random random = new Random();
        double random_prob = random.nextDouble();
        for (Value value : prob_table.keySet()) {
            if (random_prob <= prob_table.get(value)[1] && random_prob >= prob_table.get(value)[0]) {
                return value;
            }
        }

        return null;
    }

    //weighted sample
    public HashMap<Assignment, Double> Weight_Sample(Assignment a, BayesianNetwork n) {//function weighted-sample(bn,e)
        Double Weight = 1.0;//w<-1
        Assignment ass = a.copy();//an event with n elements initialized from e
        HashMap<Assignment, Double> answer = new HashMap<Assignment, Double>();
        List<RandomVariable> vars = n.getVariablesSortedTopologically();
        for (RandomVariable var : vars) {//for variable Xi in X1...Xn do
            if (ass.containsKey(var)) {//if Xi is an evidence variable with value xi in e
                Weight *= n.getProbability(var, ass);//then w<- w x P(Xi=xi\parents(Xi))
            } else {
                ass.put(var, Random_sample(var, ass, n));//x[i]<- a random sample from P(Xi|parents(Xi))
            }
        }
        answer.put(ass, Weight);
        return answer;
    }

    //likelihood Weighting
    public Distribution query(RandomVariable X, Assignment a, BayesianNetwork n, int num) {//function Likelihood-Weighting(X,e,bn,N)
        bn.base.Distribution answer = new bn.base.Distribution(X);
        for (int i = 1; i <= num; i++) {//for i = 1 to N do
            HashMap<Assignment, Double> event = Weight_Sample(a, n); //weighted-sample(bn,e)
            for (Assignment ass : event.keySet()) {
                if (!answer.containsKey(ass.get(X))) {
                    answer.put(ass.get(X), (double) (0 + event.get(ass)));
                } else {
                    answer.put(ass.get(X), (double) (answer.get(ass.get(X)) + event.get(ass)));//W[x] <- W[x] +w where x is the value of X in x
                }
            }
        }
        answer.normalize();//return normalize(W)
        return answer;
    }
    //Likelihood Weighting
    public Distribution query(RandomVariable X, Assignment a, BayesianNetwork n) {
        int num = 100000;
        bn.base.Distribution answer = new bn.base.Distribution(X);
        for (int i = 1; i <= num; i++) {
            HashMap<Assignment, Double> event = Weight_Sample(a, n);
            for (Assignment ass : event.keySet()) {
                if (!answer.containsKey(ass.get(X))) {
                    answer.put(ass.get(X), (double) (0 + event.get(ass)));
                } else {
                    answer.put(ass.get(X), (double) (answer.get(ass.get(X)) + event.get(ass)));
                }
            }
        }
        answer.normalize();
        return answer;
    }

}